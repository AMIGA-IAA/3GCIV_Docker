C  Include file for microturb rad transfer program.
C  Declaration and common statements for TAU common block
C
	INTEGER MAXT
	PARAMETER (MAXT = 20)
	REAL AT(MAXT),ATAU(MAXT),AA(MAXT)
        REAL XLO,XUP,SOUR,RADIUS,delv
 	LOGICAL hole
C
	COMMON /TAU/ AT,ATAU,AA,XLO,XUP,SOUR,RADIUS,delv,
      1			hole
