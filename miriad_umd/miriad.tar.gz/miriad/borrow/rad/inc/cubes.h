C
	real cube(MAXMOD,MAXMOD,MAXMOD,MAXTRAN)
	real crval(4),crdel(4)
        character ctyp(4)*8
	integer nsize(4)
	common /cubes_r/ crval,crdel,cube
 	common /cubes_c/ ctyp
	common /cubes_i/ nsize
