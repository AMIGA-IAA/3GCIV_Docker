c
c  Include file containing arrays for collision rates programs
c
      INTEGER MAXTEMPS
      PARAMETER (MAXTEMPS = 30)
	
      INTEGER nt
      REAL temp(MAXTEMPS)
      REAL f2(MAXLEV,MAXLEV,MAXTEMPS),a2(MAXLEV,MAXLEV,MAXTEMPS)
      
      COMMON /CRATES/ temp,f2,a2,nt
