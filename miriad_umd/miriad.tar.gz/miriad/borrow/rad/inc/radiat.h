C    Include common and declaration statements for radiative
C    transfer programs
C---------------------------------------------------------------------- 
      REAL a(MAXLEV,MAXLEV),ba(MAXLEV,MAXLEV)
      REAL be(MAXLEV,MAXLEV),col(MAXLEV,MAXLEV),ener(MAXLEV)
      REAL degen(MAXLEV),freq(MAXLEV,MAXLEV),bbk(MAXLEV,MAXLEV)
      INTEGER jklev(MAXLEV),jmax(MAXKS),kval(MAXKS),kmax
      DOUBLE PRECISION xn(MAXLEV)
      REAL ah,ak,ac,pi,rpi,brot,de,dy,tbk,v0,a0,b0,c0,dyold
      REAL dj,djk,dk,au
      INTEGER nlev,outc,nit
      INTEGER npts
      REAL rnh2(MAXMOD),rtk(MAXMOD),rnx(MAXMOD),rpt(MAXMOD)
      REAL snh2(MAXMOD),sxm(MAXMOD),rcd(MAXMOD)
      REAL rmax,dopv
      REAL trad(MAXTRAN)
      INTEGER ifre
      LOGICAL wrtrans(MAXLEV,MAXLEV)

      COMMON/STAT_R/ a,ba,be,col,ener,degen,jklev,jmax,kval,kmax,brot,
     1                   de,dy,tbk,v0,freq,a0,b0,c0,dyold,bbk,dj,djk,
     2                   dk
      COMMON/STAT_I/ nlev,outc,nit
      COMMON/STAT_D/ xn
      COMMON/CONST/ ah,ak,ac,pi,rpi,au
      COMMON/RADII_I/ npts
      COMMON/RADII_R/ rnh2,rcd,rtk,rnx,rpt,rmax,dopv,snh2,
     1        sxm
      COMMON/line_r/ trad
      COMMON/line_i/ ifre,wrtrans
C------------------------------------------------------------------------
