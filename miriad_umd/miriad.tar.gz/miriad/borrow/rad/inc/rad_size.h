c
c   Include file containing maximum values for arrays in
c   all radiative transfer programs
c       MAXLEV   = max number of levels in molecule
c       MAXMOD   = max number of models or steps in r 
c       MAXKS    = max number of K levels allowed
c       MAXTRAN  = max number of transitions for file writing
c
	INTEGER MAXLEV, MAXMOD, MAXKS, MAXTRAN
	
	PARAMETER (MAXLEV = 100)
	PARAMETER (MAXMOD = 50)
	PARAMETER (MAXKS  = 10)
	PARAMETER (MAXTRAN= 51)
