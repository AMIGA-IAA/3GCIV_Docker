c
c  Include file containing initialization stuff for radiative
c  transfer programs. This should only be included at the main program
c  after the declaration and common block statements.
c
	DATA AK / 1.3806E-16 /
	DATA AH / 6.6259E-18 /
	DATA AC / 2.9979E10  /
	DATA PI / 3.1415926  /
	DATA RPI / 1.7724539 /
	DATA AU / 1.495979E13 /
