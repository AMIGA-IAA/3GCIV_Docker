C  Include file for microturb rad transfer program.
C  Declaration and common statements for RADSUP common block
C
	INTEGER JUP,JLO,IPT
	REAL GAUMU(10),STAU(10),BETAMU(10),RMU
C
	COMMON /RADSUP_I/ JUP,JLO,IPT
	COMMON /RADSUP_R/ GAUMU,STAU,BETAMU,RMU
