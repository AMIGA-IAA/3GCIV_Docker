C  Include file for microturb rad transfer program.
C  Declaration and common statements for RADTR common block
C
	DOUBLE PRECISION POPN(MAXLEV,MAXMOD)
	REAL XJ(MAXLEV,MAXLEV),BETA(MAXLEV,MAXLEV,MAXMOD)
C
	COMMON /RADTR_D/ POPN
	COMMON /RADTR_R/ XJ,BETA
